class Contact {
    constructor(name, number) {
        this.name = name;
        this.number = number;
    }
}

module.exports = Contact;