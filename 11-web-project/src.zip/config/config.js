const config = {
    port: 3000,
    dbRoute: 'mongodb://localhost/articles-db'
};

module.exports = config;